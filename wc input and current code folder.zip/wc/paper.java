import java.io.IOException;
import java.io.*;
import java.util.StringTokenizer;
import java.util.*;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.*;
import org.apache.hadoop.*;

public class paper {

  public static class TokenizerMapper
       extends Mapper<Object, Text, Text, IntWritable>{

    private final static IntWritable one = new IntWritable(1);
    private Text word = new Text();

    public void map(Object key, Text value, Context context
                    ) throws IOException, InterruptedException {
/*	
	String line=value.toString();
	String s[]=line.split("\t");
	word.set(s[3]);
        context.write(word, one);
*/
      StringTokenizer itr = new StringTokenizer(value.toString(),"\t");
	int i=0; 
	Text t=new Text();
	String s3=new String();
	String s1=new String();
	String s=new String();
      while (itr.hasMoreTokens()) {
	if((i%4)==1)
	{
		
		//t.set(itr.nextToken());
		//Text t=(Text)s;
		s1 +=itr.nextToken();
	}
	else if((i%4)==3)
	{
		//word.set(itr.nextToken());

        	//context.write(t,word);
		s3 += itr.nextToken();
	}
	else
	{
		itr.nextToken();
	}
	i++;
        
      }
	s += s3+"\t"+s1;
	
	word.set(s);
	context.write(word,one);

    }
  }

  public static class IntSumReducer extends Reducer<Text,IntWritable,Text,IntWritable> {
    private IntWritable result = new IntWritable();
    //public Text result=new Text();
	
    public void reduce(Text key, Iterable<IntWritable> values,
                       Context context
                       ) throws IOException, InterruptedException {
      
      int sum = 0;
      for (IntWritable val : values) {
        sum += val.get();
      }
      result.set(sum);
      context.write(key, result);


    }
  }



  public static void main(String[] args) throws Exception {
    Configuration conf = new Configuration();
    Job job = Job.getInstance(conf, "paper");
    job.setJarByClass(paper.class);
    job.setMapperClass(TokenizerMapper.class);
    job.setCombinerClass(IntSumReducer.class);
    job.setReducerClass(IntSumReducer.class);



    job.setOutputKeyClass(Text.class);
    job.setOutputValueClass(IntWritable.class);
    FileInputFormat.addInputPath(job, new Path(args[0]));
    FileOutputFormat.setOutputPath(job, new Path(args[1]));
    System.exit(job.waitForCompletion(true) ? 0 : 1);
  }
}
